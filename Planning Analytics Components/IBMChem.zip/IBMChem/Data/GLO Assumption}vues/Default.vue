﻿389,100
390,"Default"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,b:0.#########G|0|
374,0
360,1
7,GLO Assumption Measure
270,3
Numeric
String
Description
274,
275,
281,0
282,
371,1
7,GLO Assumption Parameter
270,4
JV Parameters
Wheatstone Ownership
Minority Interest Parameters
EnergyX Ownership
274,
275,
281,0
282,
373,0
372,0
372,00
384,0
385,0
377,4
-6
37
1930
969
378,0
382,255
379,2
0
0
11,20190718014158
381,0
32,"null\n"
