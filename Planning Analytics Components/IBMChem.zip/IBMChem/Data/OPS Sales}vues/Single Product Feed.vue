﻿389,100
390,"Single Product Feed"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,b:0.#########G|0|
374,4
7,Version
270,1
Actual
274,
275,
281,0
282,
7,Account
270,1
4999
274,Code - Description
275,
281,0
282,
7,OPS Sales Source
270,1
Base
274,
275,
281,0
282,
7,OPS Sales Measure
270,1
Amount
274,
275,
281,0
282,
360,1
7,Time Date
6,Half Year
371,2
7,Store
6,Predicted Stores
7,Product
6,Predicted Products
373,4
1,Actual
1,4999
1,Base
1,Amount
372,1
372,10
384,1
385,0
377,4
-6
37
1930
1223
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20190829074116
381,0
32,"null\n"
