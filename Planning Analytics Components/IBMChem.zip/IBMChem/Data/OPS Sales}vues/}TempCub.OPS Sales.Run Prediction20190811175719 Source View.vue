﻿389,100
390,"}TempCub.OPS Sales.Run Prediction20190811175719 Source View"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,5
7,Time Date
6,ALL
274,
281,0
282,
7,Version
6,}TempCub.OPS Sales.Run Prediction20190811175719 Source View
7,Account
6,ALL
274,
281,0
282,
7,Product
6,ALL
274,
281,0
282,
7,Store
6,ALL
274,
281,0
282,
360,1
7,OPS Sales Measure
6,ALL
274,
281,0
282,
371,1
7,OPS Sales Source
6,ALL
274,
281,0
282,
373,5
1,All Years
1,All Versions
1,All Accounts
1,All Products
1,All Stores
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20190812005719
381,1
32,"null\n"
