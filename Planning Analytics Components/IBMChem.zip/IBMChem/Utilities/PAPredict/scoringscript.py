from TM1py.Services import TM1Service
from TM1py.Utils.Utils import build_pandas_dataframe_from_cellset

tm1_credentials = {
    "address":"<YOUR TM1 SERVER>",
    "port":'<YOUR HTTP PORT>',
    "user":"<YOUR TM1 USER>",
    "password":"<YOUR TM1 PASSWORD>",
    "ssl":False
}

with TM1Service(address=tm1_credentials["address"], port=tm1_credentials["port"], user=tm1_credentials["user"], password=tm1_credentials["password"], ssl=tm1_credentials["ssl"]) as tm1:
    data = tm1.cubes.cells.execute_view(cube_name='OPS Sales', view_name='Single Product Feed', private=False)
    df = build_pandas_dataframe_from_cellset(data, multiindex=False)
    
    nv = tm1.cubes.views.get_native_view(cube_name='OPS Sales', view_name='Single Product Feed', private=False)
    mdx = nv.MDX
    
    data = tm1.cubes.cells.execute_view(cube_name='}ElementAttributes_Store', view_name='All Attributes', private=False)
    stores = build_pandas_dataframe_from_cellset(data, multiindex=False)
    
    data = tm1.cubes.cells.execute_view(cube_name='}ElementAttributes_Product', view_name='All Attributes', private=False)
    products = build_pandas_dataframe_from_cellset(data, multiindex=False)
    
    data = tm1.cubes.cells.execute_view(cube_name='GLO Weather', view_name='All Weather Values', private=False)
    weather = build_pandas_dataframe_from_cellset(data, multiindex=False)

# Reformat Store Data
stores.drop('}ElementAttributes_Store', axis=1, inplace=True)
stores.columns = ['Store', 'Region Affluence']

# Reshape Product Data
products = products.pivot(index='Product', columns='}ElementAttributes_Product', values='Values').reset_index()
products['Brand Affinity'] = products['Brand Affinity'].astype(int)
products['Product Size'] = products['Product Size'].astype(int)

# Reshape Weather Data
weather = weather.set_index(['Time Date', 'State', 'GLO Weather Measure']).unstack(level=-1).reset_index()
weather.columns = ['Time Date', 'State', 'Precipitation', 'Temperature']
weather.fillna(0, inplace=True)

# Reshape Sales Data
df.drop(['Version', 'Account', 'OPS Sales Source', 'OPS Sales Measure'], axis=1, inplace=True)
df['State'] = df['Store'].apply(lambda x: x[:3])

# ### Merge Datasets
import pandas as pd
df = pd.merge(df, stores, how='left')
df = pd.merge(df, products, how='left')
df = pd.merge(df, weather, how='left', on=['Time Date', 'State'])
df['Time Date'] = pd.to_datetime(df['Time Date'], format='%d%m%Y')

# ### Add Data Transformations
import re
import numpy as np

def ifnone(a,b):
    "`a` if `a` is not None, otherwise `b`."
    return b if a is None else a

def make_date(df, date_field:str):
    "Make sure `df[field_name]` is of the right date type."
    field_dtype = df[date_field].dtype
    if isinstance(field_dtype, pd.core.dtypes.dtypes.DatetimeTZDtype):
        field_dtype = np.datetime64
    if not np.issubdtype(field_dtype, np.datetime64):
        df[date_field] = pd.to_datetime(df[date_field], infer_datetime_format=True)
        
def add_datepart(df, field_name:str, prefix:str=None, drop:bool=True, time:bool=False):
    "Helper function that adds columns relevant to a date in the column `field_name` of `df`."
    "Sourced from FastAI"
    make_date(df, field_name)
    field = df[field_name]
    prefix = ifnone(prefix, re.sub('[Dd]ate$', '', field_name))
    attr = ['Year', 'Month', 'Week', 'Day', 'Dayofweek', 'Dayofyear', 'Is_month_end', 'Is_month_start', 
            'Is_quarter_end', 'Is_quarter_start', 'Is_year_end', 'Is_year_start']
    if time: attr = attr + ['Hour', 'Minute', 'Second']
    for n in attr: df[prefix + n] = getattr(field.dt, n.lower())
    df[prefix + 'Elapsed'] = field.astype(np.int64) // 10 ** 9
    if drop: df.drop(field_name, axis=1, inplace=True)
    return df

abt = add_datepart(df, 'Time Date', drop=False)
abt = abt[['Time Date', 'Product', 'Store', 'Values', 'Region Affluence',
       'Good Weather Impact', 'Brand Affinity', 'Product Size', 'Temperature',
       'Precipitation', 'Time Year', 'Time Month', 'Time Week', 'Time Day',
       'Time Dayofweek', 'Time Dayofyear', 'Time Is_month_end',
       'Time Is_month_start', 'Time Is_quarter_end', 'Time Is_quarter_start',
       'Time Is_year_end', 'Time Is_year_start', 'Time Elapsed']].sort_values(by=['Time Date', 'Product', 'Store'])

abt.columns = ['Time Date', 'Product', 'Store', 'Value', 'Region Affluence',
       'Good Weather Impact', 'Brand Affinity', 'Product Size', 'Temperature',
       'Precipitation', 'Time Year', 'Time Month', 'Time Week', 'Time Day',
       'Time Dayofweek', 'Time Dayofyear', 'Time Is_month_end',
       'Time Is_month_start', 'Time Is_quarter_end', 'Time Is_quarter_start',
       'Time Is_year_end', 'Time Is_year_start', 'Time Elapsed']

values = abt.to_json()
payload = {"values":[values]}

from watson_machine_learning_client import WatsonMachineLearningAPIClient
creds = {
    "url": 'https://us-south.ml.cloud.ibm.com',
    "apikey": '<YOUR WATSON MACHINE LEARNING API KEY>',
    "instance_id":'<YOUR WATSON INSTANCE ID'
}

client = WatsonMachineLearningAPIClient(creds)
scoring_url = '<YOUR WATSON MACHINE LEARNING MODEL DEPLOYMENT URL>'

predict = client.deployments.score(scoring_url, payload)

import json
predictions = json.loads(predict)


# ### Push Data Back to TM1
cellset = {tuple((abt.iloc[count]['Time Date'].strftime('%d%m%Y'), 'WML Forecast', '4999', abt.iloc[count]['Product'], abt.iloc[count]['Store'], 'Base', 'Amount')):prediction for count, prediction in enumerate(predictions['predictions'])}

with TM1Service(address=tm1_credentials["address"], port=tm1_credentials["port"], user=tm1_credentials["user"], password=tm1_credentials["password"], ssl=tm1_credentials["ssl"]) as tm1:
    tm1.cubes.cells.write_values('OPS Sales', cellset, dimensions=['Time Date', 'Version', 'Account', 'Product', 'Store', 'OPS Sales Source', 'OPS Sales Measure'])

